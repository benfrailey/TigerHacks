let liveCamera = false;

export function isLiveCamera() {
  return liveCamera;
}

export function setLiveCamera(isLiveCamera) {
  liveCamera = isLiveCamera;
}
