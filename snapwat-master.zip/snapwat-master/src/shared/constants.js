export const HEADER_HEIGHT = 72;

export const PAGES = {
  HOME: 'home',
  ANNOTATE: 'annotate',
  SNAPSHOT: 'snapshot',
  SHARE: 'share',
  ABOUT: 'about'
};
